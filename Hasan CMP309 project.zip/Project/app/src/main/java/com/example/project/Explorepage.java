package com.example.project;

import android.app.Activity;

public class Explorepage extends Activity {
}
