package com.example.project

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

@Suppress("DEPRECATION")
class HomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        // Navigate after 3 seconds (splash behavior)
        Handler().postDelayed({
            val intent = Intent(this, ExplorePage::class.java)
            startActivity(intent)
            finish()
        }, 3000)

        // Setup View Restaurants button
        val exploreButton: Button = findViewById(R.id.view_restaurant_button)
        exploreButton.setOnClickListener {
            val intent = Intent(this, ExplorePage::class.java)
            startActivity(intent)
        }
    }
}