package com.example.project

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ExplorePage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_explorepage)

        findViewById<Button>(R.id.milas_button).setOnClickListener {
            startActivity(Intent(this, Milas::class.java))
        }

        findViewById<Button>(R.id.taza_button).setOnClickListener {
            startActivity(Intent(this, Taza::class.java))
        }

        findViewById<Button>(R.id.tahini_button).setOnClickListener {
            startActivity(Intent(this, Tahini::class.java))
        }

        findViewById<Button>(R.id.babujee_button).setOnClickListener {
            startActivity(Intent(this, Babujee::class.java))
        }

        findViewById<Button>(R.id.Jahangir_button).setOnClickListener {
            startActivity(Intent(this, Jahangir::class.java))
        }
    }
}